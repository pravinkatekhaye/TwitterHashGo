//Twitter service.js
(function(){
  angular.module('twitterApp.services', [])
      .factory('twitterService', function($q, $http, $location) {
       var authorizationResult = false;
    return {
        initialize: function () {

            //initialize OAuth.io with public key of the application
            OAuth.initialize('5pE3BgzmblTswXo5jc_F74iUaLA', {cache: true});
            //try to create an authorization result when the page loads, this means a returning user won't have to click the twitter button again
            authorizationResult = OAuth.create('twitter');

        },

        isReady: function () {
            return (authorizationResult);

        },

        connectTwitter: function () {
            var deferred = $q.defer();
            OAuth.popup('twitter', {cache: true}, function (error, result) { //cache means to execute the callback if the tokens are already present
                if (!error) {

                    authorizationResult = result;

                    $location.path('/home');

                } else {
                    //do something if there's an error
                    alert("Problem in connect Twitter")
                }
            });
            return deferred.promise;

        },

        clearCache: function () {

            OAuth.clearCache('twitter');
            authorizationResult = false;

        },

        getLatestTrends: function (woeid) {

            //create a deferred object using Angular's $q service
            var deferred = $q.defer();
            if(woeid)
            {
              var url='/1.1/trends/place.json?id='+woeid;
            }
            else{
                var url = "/1.1/trends/place.json?id=1";
            }

            var promise = authorizationResult.get(url).done(function (data) {
                //when the data is retrieved resolve the deferred object
                console.log(data);
                deferred.resolve(data);
            }).fail(function (err) {
                //in case of any error we reject the promise with the error object
                deferred.reject(err);
            });

            //return the promise of the deferred object
            return deferred.promise;
        },

        getRelatedTweetsOfHashtag: function (hashtag) {

            var encodedhashtag = hashtag.replace("#", "%28%23");
            var deferred = $q.defer();

            var url = '/1.1/search/tweets.json?q=' + encodedhashtag + '&src=typd&result_type=recent';

            var promise = authorizationResult.get(url).done(function (data) {
                //when the data is retrieved resolve the deferred object
                console.log(data);
                deferred.resolve(data);
            }).fail(function (err) {
                //in case of any error we reject the promise with the error object
                deferred.reject(err);
            });
            return deferred.promise;
        },

        requestForLikeTweet: function (id) {

            var deferred = $q.defer();
            var url = '/1.1/favorites/create.json?id=' + id;
            var promise = authorizationResult.post(url).done(function (data) {
                //when the data is retrieved resolve the deferred object
                deferred.resolve(data);
            }).fail(function (err) {
                //in case of any error we reject the promise with the error object
                deferred.reject(err);
            });
            //return the promise of the deferred object
            return deferred.promise;
        },

        getHomeTimelineTweets: function () {
            var deferred = $q.defer();
            var url = '/1.1/statuses/home_timeline.json';

            var promise = authorizationResult.get(url).done(function (data) {
                //when the data is retrieved resolve the deferred object
                console.log(data);
                deferred.resolve(data);
            }).fail(function (err) {
                //in case of any error we reject the promise with the error object
                deferred.reject(err);

            });
            //return the promise of the deferred object
            return deferred.promise;
        },

        getwoeidOfPlace: function (placename) {

            var deferred = $q.defer();

            var url='/1.1/trends/available.json';

            var promise = authorizationResult.get(url).done(function (data) {
                //when the data is retrieved resolve the deferred object
                
                deferred.resolve(data);
            }).fail(function (err) {
                //in case of any error we reject the promise with the error object
                deferred.reject(err);
            });

            //return the promise of the deferred object
            return deferred.promise;

           },
		    getuserProfileDetail: function () {

            var deferred = $q.defer();

            var url='/1.1/account/verify_credentials.json';

            var promise = authorizationResult.get(url).done(function (data) {
                //when the data is retrieved resolve the deferred object
                console.log(data);
                deferred.resolve(data);
            }).fail(function (err) {
                //in case of any error we reject the promise with the error object
                deferred.reject(err);
            });

            //return the promise of the deferred object
            return deferred.promise;

           }
		   
		   
         }
     });
})();